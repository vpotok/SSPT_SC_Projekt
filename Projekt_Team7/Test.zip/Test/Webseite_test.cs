using NUnit.Framework;
using Projekt_Team7;
using System;
using System.IO;

namespace Projekt_Team7
{
    [TestFixture]
    public class WebseiteTests
    {
        [Test]
        public void Start_ShouldExecuteCorrectLogic()
        {
            // Arrange
            var webseite = new Webseite();

            // Set up test inputs
            string url = "webshop.at";
            int port = 443;
            string modellArt = "Auto";
            string modell = "A4";

            // Set up console input for testing
            using (var stringReader = new StringReader($"{url}{Environment.NewLine}{port}{Environment.NewLine}Kaufen{Environment.NewLine}{modellArt}{Environment.NewLine}{modell}{Environment.NewLine}Close{Environment.NewLine}"))
            {
                Console.SetIn(stringReader);

                // Act
                webseite.start();

                // Assert
                // Add assertions to verify the expected behavior of the start() method
            }
        }

        // Add more unit tests for other methods in the Webseite class

        // Consider writing tests for error cases and edge cases as well.
    }
}
